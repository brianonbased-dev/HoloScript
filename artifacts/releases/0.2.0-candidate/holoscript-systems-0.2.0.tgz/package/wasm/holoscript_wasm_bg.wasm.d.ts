/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const compile_to_kotlin: (a: number, b: number, c: number, d: number, e: number) => void;
export const compile_to_uaal: (a: number, b: number, c: number) => void;
export const init: () => void;
export const parse: (a: number, b: number, c: number) => void;
export const parse_pretty: (a: number, b: number, c: number) => void;
export const validate: (a: number, b: number) => number;
export const validate_detailed: (a: number, b: number, c: number) => void;
export const version: (a: number) => void;
export const __wbindgen_export: (a: number, b: number, c: number) => void;
export const __wbindgen_export2: (a: number, b: number) => number;
export const __wbindgen_export3: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_start: () => void;
