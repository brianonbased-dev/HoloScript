export function add(left: i32, right: i32): i32 {
  return left + right
}
