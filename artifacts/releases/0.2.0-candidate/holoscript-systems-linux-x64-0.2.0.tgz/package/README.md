# @holoscript/systems-linux-x64

Native linux-x64 compiler package for `@holoscript/systems@0.2.0`. Install the meta package instead of depending on this package directly.
