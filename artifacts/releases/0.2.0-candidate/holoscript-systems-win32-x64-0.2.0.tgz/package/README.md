# @holoscript/systems-win32-x64

Native win32-x64 compiler package for `@holoscript/systems@0.2.0`. Install the meta package instead of depending on this package directly.
